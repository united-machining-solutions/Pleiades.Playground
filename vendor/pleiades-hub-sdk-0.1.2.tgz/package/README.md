# @pleiades/hub-sdk

The package an app uses to register at the Pleiades Hub. The backend of an app creates one client and names
its apps. The SDK does the rest over MQTT: it announces the apps, answers the requests of the hub, reconnects
by itself and signs off when the process stops. This is version 0.1.2.

To register an app from another repository, follow [Register an app](register-an-app.md): the steps, the
variables and how to check the result. This page is the reference.

What travels over the broker is defined in the [MQTT contract](../../contracts/mqtt/README.md); this package
is its implementation in TypeScript. The decisions behind it are
[ADR-0006](../../docs/adr/0006-app-registry-and-discovery-over-mqtt.md), on the registry and the discovery,
and [ADR-0007](../../docs/adr/0007-hub-sdk-package-and-tarball.md), on the package and how it reaches an app.

## Install

**Inside the hub** the package is linked from the workspace: a package of the hub names
`"@pleiades/hub-sdk": "workspace:*"` as a dependency. The `exports` of the SDK point at `src` there, so the
consumer runs the TypeScript source directly and nothing has to be built first.

**In another repository** the package comes as a tarball. It is not published to an npm registry.

1. In the hub, run `pnpm sdk:pack` at the repository root. It builds the package and writes
   `artifacts/pleiades-hub-sdk-0.1.2.tgz`, with JavaScript, types, this README, the license and the guide
   `register-an-app.md`.
2. Check the file into the consuming repository under `vendor/`, with a `vendor/README.md` that names the
   version and where the file comes from.
3. Refer to the file with `file:` in the pnpm catalog of that repository.

A change to the SDK reaches such a repository only with a new version and a new tarball.

The SDK is licensed under the Apache License, Version 2.0; see [LICENSE](LICENSE).

## Usage

One client per backend process, for all apps of that process:

```ts
import { createHubClient } from "@pleiades/hub-sdk"

const hub = createHubClient({
  brokerUrl: "mqtt://localhost:1883", // the broker of the Playground
  clientId: "pleiades-documentation", // a fixed name, the same at every start
  apps: [
    {
      id: "pleiades-documentation",
      label: { en: "Documentation", de: "Dokumentation" },
      description: {
        en: "Documentation packages for machines",
        de: "Dokumentationspakete für Maschinen",
      },
      url: "/documentation/",
      icon: "api/hub/icon.svg", // relative to url: /documentation/api/hub/icon.svg
    },
    {
      id: "pleiades-documentation-search",
      label: { en: "Search", de: "Suche" },
      url: "/documentation/search/",
      icon: "/documentation/icons/search.svg", // a path from the address of the hub
    },
  ],
  onError: (error) => console.error(`hub: ${error.message}`),
})

// At runtime: every change sends the new list of the client.
hub.register({
  id: "pleiades-documentation-import",
  label: { en: "Import", de: "Import" },
  url: "/documentation/import/",
  icon: "https://assets.example.org/import.svg", // a full URL
})
hub.unregister("pleiades-documentation-search")

// Sign off before the process ends.
process.on("SIGTERM", () => {
  void hub.stop().finally(() => process.exit(0))
})
```

The apps `pleiades-documentation-search` and `pleiades-documentation-import` are made up for the example.

- `clientId` is a fixed name that the app chooses, not a value per start. A restarted process then replaces
  the list of its predecessor at once.
- `apps` is optional. A client can start without an app and register one later.
- `register` adds the app, or replaces the one with the same id. `unregister` takes the id of the app.
- `stop()` signs the client off at the hub. If a process ends without it, the broker signs off for the
  client, through the Last Will of the connection.

## API

```ts
// Language code (BCP 47) -> text, at least one entry.
export type Translations = Record<string, string>

export type AppRegistration = {
  id: string
  label: Translations
  url: string // absolute http(s) URL, or a path that starts with "/"
  description?: Translations
  icon?: string // link to an SVG: full http(s) URL, path that starts with "/", or path relative to url
}

export type HubClientOptions = {
  brokerUrl: string
  clientId: string
  apps?: AppRegistration[]
  username?: string
  password?: string
  onError?: (error: Error) => void
}

export type HubClient = {
  register(app: AppRegistration): void // adds the app, or replaces the one with the same id
  unregister(appId: string): void
  stop(): Promise<void>
}

// Throws on invalid input. A broker that cannot be reached never throws: it is retried.
export function createHubClient(options: HubClientOptions): HubClient
```

| Field of an app | Rule |
|---|---|
| `id` | `^[a-z0-9][a-z0-9-]{0,62}$`, as `clientId`. Unique in the whole hub: if two clients announce one id, the last one wins |
| `label` | Language code (`en`, `de-CH`) to a non-empty text. At least one entry, and it should contain `en` |
| `description` | Optional. Language code to a non-empty text |
| `url` | An absolute `http` or `https` URL, or a path that starts with exactly one `/` |
| `icon` | Optional. A link to an SVG, at most 2048 characters, see "The icon link" |

Neither `url` nor `icon` may contain a backslash, whitespace or a control character. Any scheme other than
`http` and `https` (`javascript:`, `data:` and so on) and a leading `//` are invalid.

A path as `url`, such as `/documentation/`, is resolved in the browser against the address of the hub. That
is enough where the hub and the app are served behind one port. In development with separate ports the app
names its full URL, for example `http://localhost:3200/`.

`username` and `password` are for a broker that asks for them. The broker of the Playground is anonymous.

## The icon link

`icon` is a link to an SVG. Only the form of the link is checked: the hub does not fetch the file and does
not check its content. Three forms are allowed:

| Form | Example | Resolved |
|---|---|---|
| A full `http` or `https` URL | `https://assets.example.org/import.svg` | not at all, it is complete |
| A path that starts with exactly one `/` | `/documentation/icons/search.svg` | against the address of the hub |
| A relative path | `api/hub/icon.svg` | against the `url` of the app, by the rules for URLs |

A relative icon moves with the app: where `url` is a path, the icon is looked for below the address of the
hub, and where `url` is a full URL, as in development with separate ports, below that URL.

**Mind the slash at the end of `url`.** By the rules for URLs a relative path takes the place of everything
behind the last `/` of its base:

| `url` | `icon` | Where the icon is looked for |
|---|---|---|
| `/documentation/` | `icon.svg` | `/documentation/icon.svg` |
| `/documentation` | `icon.svg` | `/icon.svg` |

**An icon brings its own colours.** The hub UI shows the icon as an image (`<img>`). So no script in the file
runs, and the file does not take over the text colour of the page: `currentColor` becomes black. Write the
colours into the SVG.

## The entry `@pleiades/hub-sdk/contract`

The part of the package that has no dependencies has an entry of its own, so a browser bundle can use it
without the MQTT client:

```ts
export const TOPICS: {
  discover: string
  announce(clientId: string): string
  offline(clientId: string): string
}

export type Announcement = {
  clientId: string
  instanceId: string
  timestamp: string
  apps: AppRegistration[] // only the valid apps
}

export function parseAnnouncement(topic: string, payload: Uint8Array): Announcement | null

// The first match wins: a language as given, then without its region, then "en", then the first entry.
export function pickTranslation(translations: Translations, languages: readonly string[]): string

// Resolves url against the origin of the hub. For icon: a full URL stays, a path that starts with "/"
// resolves against the origin of the hub, a relative path against the resolved url.
export function resolveAppLinks(
  app: Pick<AppRegistration, "url" | "icon">,
  hubOrigin: string,
): { url: string; icon?: string }
```

`pickTranslation` chooses the text for a reader, and `resolveAppLinks` turns the links of an app into the
addresses a browser can load:

```ts
import { pickTranslation, resolveAppLinks } from "@pleiades/hub-sdk/contract"

const label = { en: "Documentation", de: "Dokumentation" }
pickTranslation(label, ["de-CH"]) // "Dokumentation": there is no "de-CH", but "de"
pickTranslation(label, ["fr"]) // "Documentation": there is no "fr", so "en"

resolveAppLinks({ url: "/documentation/", icon: "api/hub/icon.svg" }, "http://localhost:3300")
// url:  http://localhost:3300/documentation/
// icon: http://localhost:3300/documentation/api/hub/icon.svg
```

`parseAnnouncement` reads a message from `hub/clients/{ClientId}/announce` the way the registry of the hub
needs it: it returns `null` when the whole message is discarded, and otherwise the announcement with only
its valid apps. The rules are under "Validation" in the [contract](../../contracts/mqtt/README.md). `TOPICS`
holds the three topics of the contract.

## Errors

- **Invalid input throws at once.** `createHubClient` and `register` throw for an invalid client id, an
  invalid app id or `url`, an empty `label`, an invalid icon link, and for the same app id twice in `apps`.
  `createHubClient` also throws for a `brokerUrl` that is not an `mqtt`, `mqtts`, `ws` or `wss` URL, and for a
  `password` without a `username`: a broker takes a password only together with a user name. A mistake in a
  registration shows at the start of the process, not as an app that is missing in the hub.
- **An unreachable broker never throws.** The SDK retries and reconnects by itself, and it sends the list
  again on every connect. An app can therefore start before the broker and before the hub. What goes wrong on
  the connection is passed to `onError`, if the option is set.
- **A message is at most 256 KiB.** The SDK checks the size of the list before it sends it: `createHubClient`
  and `register` throw for a list that is larger. The hub drops a larger message.

## How it works

The SDK is built on the npm package `mqtt` and keeps one MQTT connection per client, for all its apps. Over
that connection it

- sends the complete list of the client on every connect and reconnect,
- sends it again after every `register` and `unregister`,
- answers every `hub/discover` of the hub with it, and
- sends `offline` on `stop()`. The same message is the Last Will of the connection, for a process that
  crashes.

Every list carries an `instanceId` that the SDK assigns once per process start. The hub uses it to tell the
sign-off of an old connection from a client that has just restarted. The details are in the
[contract](../../contracts/mqtt/README.md).

## Scripts and layout

| Command | What it does |
|---|---|
| `pnpm --filter @pleiades/hub-sdk test` | Runs the tests of the package |
| `pnpm --filter @pleiades/hub-sdk build` | Builds JavaScript and types into `dist` |
| `pnpm sdk:pack` (at the repository root) | Builds the package and writes `artifacts/pleiades-hub-sdk-0.1.2.tgz`, which git ignores |

| File | What it holds |
|---|---|
| `src/contract.ts` | The contract part, without dependencies. It must also run in a browser |
| `src/client.ts` | The client part, on the npm package `mqtt` |
| `src/index.ts` | The entry of the package |
| [`package.json`](package.json) | `exports` point at `src` for the workspace, `publishConfig` at `dist` for the tarball |

The SDK is the only package of the hub with a build step. Inside the workspace nobody needs the build: the
hub API runs the TypeScript source. The build exists for the tarball.

A C# library is not part of this package. It can follow against the
[contract](../../contracts/mqtt/README.md), which is language-neutral.
