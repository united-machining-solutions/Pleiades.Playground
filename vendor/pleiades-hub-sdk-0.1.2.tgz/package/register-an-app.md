# Register an app at the Pleiades Hub

A guide for developers and coding agents who work in the repository of an app, not in the hub. It leads from
nothing to an app that appears in the launcher of the hub. The reference for everything named here is the
[README of the SDK](README.md); what travels over the broker is the
[MQTT contract](../../contracts/mqtt/README.md).

The guide is part of the package from version 0.1.1 on: in the repository of an app it lies at
`node_modules/@pleiades/hub-sdk/register-an-app.md`, next to the README. A link that leaves this folder
points into the repository of the hub, `umati/pleiades-hub`.

## What you need

- **A backend in Node.js.** The registration runs in a server process, never in the browser: the SDK keeps a
  connection to the MQTT broker for as long as the process lives. An app without a Node backend registers
  [without the SDK](#without-the-sdk).
- **The broker.** The hub and every app meet at the Mosquitto of the Pleiades Playground, port 1883,
  anonymous. The hub itself needs no configuration for a new app.
- **An address.** The URL, or the path, under which a user's browser reaches the app.
- **A page that may be embedded.** The hub opens the app in an iframe. The app, and any proxy in front of
  it, must send neither `X-Frame-Options` nor a `frame-ancestors` directive that excludes the hub.

## Steps

### 1. Bring the SDK into the repository

The SDK is not published to an npm registry. It comes as a tarball that is checked in.

1. In `pleiades-hub`, run `pnpm sdk:pack`. It writes `artifacts/pleiades-hub-sdk-0.1.2.tgz`.
2. Copy the file to `vendor/` in the repository of the app, and note version, origin and checksum in a
   `vendor/README.md`, so a stale copy is noticed.
3. In a pnpm workspace with a catalog, add the entry to the catalog in `pnpm-workspace.yaml`:

   ```yaml
   catalog:
     "@pleiades/hub-sdk": file:vendor/pleiades-hub-sdk-0.1.2.tgz
   ```

   and name the dependency in the `package.json` of the backend:

   ```json
   "@pleiades/hub-sdk": "catalog:"
   ```

   Without a catalog, the `file:` reference stands in the `package.json` itself. That way was not tried here.
4. Run `pnpm install` and commit the tarball together with the lockfile, which records its checksum.
5. If the app is built as a container image, the tarball must be there when the image installs: let `vendor`
   through in `.dockerignore` (`!vendor`), and copy it before `pnpm install` in every Dockerfile that copies
   single files. Otherwise `pnpm install --frozen-lockfile` fails in the image build.
6. For coding agents, copy the skill `.claude/skills/register-hub-app/SKILL.md` of `pleiades-hub` to the same
   place in the repository of the app, unchanged, with a `SOURCE.md` that names where it comes from and the
   version of the SDK. The skill leads an agent to this guide. An agent that does not read
   `.claude/skills/` needs a sentence in the `AGENTS.md` of the app that names this guide.

### 2. Register when the backend starts

Keep the registration in one module. It is opt-in: without a broker it does nothing, so the app runs
unchanged wherever there is no hub.

```ts
// hub.ts
import { createHubClient } from "@pleiades/hub-sdk"
import type { HubClient } from "@pleiades/hub-sdk"

export function startHubRegistration(env: NodeJS.ProcessEnv = process.env): HubClient | undefined {
  if (!env.HUB_MQTT_URL) return undefined
  return createHubClient({
    brokerUrl: env.HUB_MQTT_URL,
    clientId: "my-app", // a fixed name, the same at every start
    apps: [
      {
        id: "my-app",
        label: { en: "My App", de: "Meine App" },
        description: { en: "What it does", de: "Was sie tut" }, // optional
        url: env.HUB_APP_URL || "http://localhost:4000/", // the address in development as the default
        icon: "hub-icon.svg", // optional, relative to url
      },
    ],
    onError: (error) => console.error(`Hub registration: ${error.message}`),
  })
}
```

Call it once, after the server listens, and sign off when the process stops:

```ts
const hub = startHubRegistration()

process.on("SIGTERM", () => {
  void (hub?.stop() ?? Promise.resolve()).finally(() => process.exit(0))
})
```

That is all. The SDK announces the apps, answers the requests of the hub and reconnects by itself. If the
process dies without `stop()`, the broker signs off for it, through the Last Will of the connection.

Three things to get right:

- **One client per process.** A dev server that reloads modules must not create a second one: keep the
  client in a singleton, for example on `globalThis`.
- **`onError` is called on every retry.** The SDK retries every two seconds, so log each distinct message
  once.
- **The broker URL can carry a password.** Do not log it.

One client can register several apps: more entries in `apps`, or `hub.register(app)` and
`hub.unregister(appId)` at runtime.

### 3. Serve the icon

The icon is an SVG that the app serves itself, registered as a link. A relative link such as `hub-icon.svg`
is resolved against `url`, so it stays right when the app later moves behind a path of the hub.

- The hub shows the icon as an image. It must bring its own colours: `currentColor` becomes black.
- `url` must end with `/`. Next to `/my-app` without the slash, `hub-icon.svg` is looked for at
  `/hub-icon.svg`.
- Without an icon, or when it does not load, the hub shows the initials of the label.

### 4. Name the variables

By convention an app reads two variables. Add their names to the `.env.example` of the app, and pass them to
the container in its Compose file.

| Variable | Meaning |
|---|---|
| `HUB_MQTT_URL` | The broker: an `mqtt`, `mqtts`, `ws` or `wss` URL. Empty: no registration |
| `HUB_APP_URL` | The address under which a browser reaches the app: an absolute `http` or `https` URL, or a path that starts with `/`, such as `/my-app/` |

| Where the app runs | `HUB_MQTT_URL` |
|---|---|
| On the computer, next to the Playground stack | `mqtt://localhost:1883` |
| In a container of its own stack | `mqtt://host.docker.internal:1883`, with `extra_hosts: host.docker.internal:host-gateway` for Docker Engine on Linux |
| In the stack of the Playground | `mqtt://broker:1883` |

## The fields of an app

| Field | Rule |
|---|---|
| `clientId`, `id` | Lower-case letters, digits and `-`, at most 63 characters, starting with a letter or digit. The `id` of an app is unique in the whole hub |
| `label` | Language code to text, at least one entry. It should contain `en` |
| `description` | Optional, as `label` |
| `url` | An absolute `http` or `https` URL, or a path that starts with exactly one `/` |
| `icon` | Optional. A full `http` or `https` URL, a path that starts with `/` (from the address of the hub), or a relative path (from `url`) |

## What happens when something is wrong

- **Invalid input throws at once.** `createHubClient` and `register` throw for an invalid id, address, label
  or icon link. The mistake shows when the process starts, not as an app that is missing in the hub.
- **An unreachable broker never throws.** The SDK retries, and the app runs as usual. Start order does not
  matter.

## Check that it works

1. Start the Playground stack. It publishes the broker on `localhost:1883`.
2. Start the hub: `docker compose up -d --build --wait` in `pleiades-hub`, then open http://localhost:3300.
3. Start the app with `HUB_MQTT_URL` set.

The registration is done when all of this holds:

- `GET http://localhost:3300/api/apps` answers with `"broker": "connected"` and lists the app with its `id`,
  `label`, `url` and `icon`.
- The launcher shows the app with its icon, not its initials, and the app opens in the hub.
- After the app is stopped, the hub no longer lists it, within a second.
- Without `HUB_MQTT_URL`, the app starts and opens no connection to a broker.

If the app is not listed, look at these first:

| What you see | Likely cause |
|---|---|
| `"broker": "disconnected"` | The hub does not reach the broker. Is the Playground stack running, and is port 1883 its broker? |
| The broker is connected, the app is missing | The app talks to another broker (`localhost` inside a container is the container itself), or `HUB_MQTT_URL` did not reach the process |
| Initials instead of the icon | The icon link resolves to the wrong address (`url` without `/` at the end), or the app does not serve the file |
| The app is listed, the iframe stays empty | `url` is not reachable from the browser, or the app refuses to be embedded |

## Working examples

Two apps register this way. Both are in repositories of their own:

- **Pleiades Documentation**, a Hono API: `apps/api/src/hub.ts` holds the registration, `server.ts` starts it
  after `serve` and stops it in `shutdown()`, and the icon is a route of the API.
- **Pleiades Playground**, TanStack Start on Nitro: `apps/app/src/hub/` holds the settings, the singleton
  and a Nitro plugin that starts the registration with the server; the icon lies in `public/`.

## Without the SDK

An app whose backend is not Node.js, C# for example, registers with any MQTT client from version 3.1.1 on:
it publishes the list of its apps as JSON on `hub/clients/{ClientId}/announce`, answers `hub/discover` with
it, and sets `hub/clients/{ClientId}/offline` as its Last Will. The
[MQTT contract](../../contracts/mqtt/README.md) defines all of it. There is no library for another language
yet.
